
import copy
import re


def apply_requirement(spec, text):
    spec, t, notes = copy.deepcopy(spec), text.lower(), []
    S = spec["services"]
    did = re.search(r"did\s*(?:0x)?([0-9a-f]{4})", t)
    rt = re.search(r"routine\s*(?:0x)?([0-9a-f]{4})", t)
    rng = re.search(r"(\d+)\s*(?:to|-|and)\s*(\d+)", t)
    needs_ses = bool(re.search(r"extended|programming|non-default|not in default", t))
    needs_sec = bool(re.search(r"unlock|security|seed|\bkey\b", t))
    if did and "writ" in t:
        d = S["2E"]["dids"].setdefault(did.group(1).upper(), {"size": 2})
        notes.append(f"Write DID {did.group(1).upper()} added or updated.")
        if needs_ses: d["session"] = "extended"; notes.append("Requires a non-defaultsession.")
        if needs_sec: d["security"] = True; notes.append("Requires security unlocked.")
        if rng:
            d["min"], d["max"] = int(rng.group(1)), int(rng.group(2))
            notes.append(f"Value range set to {d['min']} to {d['max']}.")
    elif did and "read" in t:
        S["22"]["dids"].setdefault(did.group(1).upper(), {})
        notes.append(f"Read DID {did.group(1).upper()} added.")
    elif rt:
        r = S["31"]["routines"].setdefault(rt.group(1).upper(), {"subfunctions": [1, 3]})
        notes.append(f"Routine {rt.group(1).upper()} added or updated.")
        if needs_ses: r["session"] = "extended"; notes.append("Requires a non-defaultsession.")
        if re.search(r"current|load|moving", t):
            r["blocked_under_current"] = True; notes.append("Start is blocked while pack current is above 0 A.")
    if not notes:
        notes.append("Could not map that to a rule. Mention a DID or routine")
    return spec, notes
