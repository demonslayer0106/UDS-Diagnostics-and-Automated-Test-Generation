
import json
from pathlib import Path

SPEC_PATH = Path(__file__).with_name("spec.json")


def load_spec(path=None):
    return json.loads(Path(path or SPEC_PATH).read_text())


def save_spec(spec, path=None):
    Path(path or SPEC_PATH).write_text(json.dumps(spec, indent=2) + "\n")


def _pair(h):
    return " ".join(h[i:i + 2] for i in range(0, len(h), 2))


def _val(v, size):
    return " ".join(f"{(v >> (8 * i)) & 255:02X}" for i in reversed(range(size)))


def generate(spec):
    out, S = [], spec["services"]

    def add(name, setup, req, exp, cat, rid):
        out.append({"name": name, "setup": setup, "request": req, "expected": exp,
                    "category": cat, "req_id": rid})

    def bad_sub(subs):
        return next(x for x in range(1, 0x7F) if x not in subs)

    if "10" in S:
        subs = S["10"]["subfunctions"]
        for s in subs:
            add(f"Session 0x{s:02X} accepted", [], f"10 {s:02X}", f"50 {s:02X}", "nominal", "REQ-10")
        add("Unknown session rejected", [], f"10 {bad_sub(subs):02X}", "7F 10 12", "negative", "REQ-10")
        add("Short session frame rejected", [], "10", "7F 10 13", "length", "REQ-10")
        add("Suppressed positive reply", [], f"10 {subs[0] | 0x80:02X}", "none", "suppress", "REQ-10")
    if "3E" in S:
        subs = S["3E"]["subfunctions"]
        add("Tester present answered", [], f"3E {subs[0]:02X}", f"7E {subs[0]:02X}", "nominal", "REQ-3E")
        add("Tester present bad subfunction", [], f"3E {bad_sub(subs):02X}", "7F 3E 12", "negative", "REQ-3E")
        add("Tester present suppressed", [], f"3E {subs[0] | 0x80:02X}", "none", "suppress", "REQ-3E")
        add("Tester present short frame", [], "3E", "7F 3E 13", "length", "REQ-3E")
    if "11" in S:
        s = S["11"]
        for sub in s["subfunctions"]:
            add(f"Reset 0x{sub:02X} in extended session", ["ext"], f"11 {sub:02X}", f"51 {sub:02X}", "nominal", "REQ-11")
        if s.get("session"):
            add("Reset refused in default session", [], f"11 {s['subfunctions'][0]:02X}", "7F 11 7F", "session", "REQ-11")
        add("Reset bad subfunction", ["ext"], f"11 {bad_sub(s['subfunctions']):02X}", "7F 11 12", "negative", "REQ-11")
        add("Reset long frame", ["ext"], f"11 {s['subfunctions'][0]:02X} 00", "7F 11 13", "length", "REQ-11")
    if "22" in S:
        known = S["22"]["dids"]
        for did in known:
            add(f"Read DID {did}", [], f"22 {_pair(did)}", f"62 {_pair(did)}", "nominal", f"REQ-22-{did}")
        if "FFFF" not in known:
            add("Read unknown DID", [], "22 FF FF", "7F 22 31", "negative", "REQ-22")
        add("Read with truncated DID", [], "22 0A", "7F 22 13", "length", "REQ-22")
    if "27" in S:
        s = S["27"]
        if s.get("session"):
            add("Seed refused in default session", [], "27 01", "7F 27 7F", "session", "REQ-27")
        add("Seed granted", ["ext"], "27 01", "67 01", "nominal", "REQ-27")
        add("Key before seed", ["ext"], "27 02 00 00 00 00", "7F 27 24", "sequence", "REQ-27")
        add("Wrong key", ["ext", "seed"], "27 02 00 00 00 00", "7F 27 35", "security", "REQ-27")
        add("Correct key", ["ext", "seed"], "27 02 KEY", "67 02", "security", "REQ-27")
        add("Security bad subfunction", ["ext"], f"27 {bad_sub(s['subfunctions']):02X}", "7F 27 12", "negative", "REQ-27")
        add("Seed request long frame", ["ext"], "27 01 00", "7F 27 13", "length", "REQ-27")
    if "2E" in S:
        for did, d in S["2E"]["dids"].items():
            rid, sp, size = f"REQ-2E-{did}", _pair(did), d.get("size", 2)
            lo, hi = d.get("min", 0), d.get("max", (1 << (8 * size)) - 1)
            mid = (lo + hi) // 2
            ses = ["ext"] if d.get("session") else []
            ok = ["ext", "seed", "key"] if d.get("security") else ses
            if d.get("session"):
                add(f"Write {did} refused in default session", [], f"2E {sp} {_val(mid, size)}", "7F 2E 7F", "session", rid)
            if d.get("security"):
                add(f"Write {did} refused while locked", ses, f"2E {sp} {_val(mid, size)}", "7F 2E 33", "security", rid)
            for label, v in (("minimum", lo), ("maximum", hi)):
                add(f"Write {did} at {label}", ok, f"2E {sp} {_val(v, size)}", f"6E {sp}", "boundary", rid)
            if "min" in d and lo > 0:
                add(f"Write {did} below minimum", ok, f"2E {sp} {_val(lo - 1, size)}", "7F 2E 31", "boundary", rid)
            if "max" in d and hi < (1 << (8 * size)) - 1:
                add(f"Write {did} above maximum", ok, f"2E {sp} {_val(hi + 1, size)}", "7F 2E 31", "boundary", rid)
            add(f"Write {did} short payload", ok, f"2E {sp} {_val(mid, size)[:-3]}", "7F 2E 13", "length", rid)
    if "31" in S:
        for rt, d in S["31"]["routines"].items():
            rid, sp, subs = f"REQ-31-{rt}", _pair(rt), d["subfunctions"]
            if d.get("session"):
                add(f"Routine {rt} refused in default session", [], f"31 {subs[0]:02X} {sp}", "7F 31 7F", "session", rid)
            for s in subs:
                add(f"Routine {rt} subfunction 0x{s:02X}", ["ext"], f"31 {s:02X} {sp}", f"71 {s:02X} {sp}", "nominal", rid)
            if d.get("blocked_under_current"):
                add(f"Routine {rt} blocked under load", ["ext", "amps"], f"31 {subs[0]:02X} {sp}", "7F 31 22", "environment", rid)
            add(f"Routine {rt} bad subfunction", ["ext"], f"31 {bad_sub(subs):02X} {sp}", "7F 31 12", "negative", rid)
            add(f"Routine {rt} short frame", ["ext"], f"31 {subs[0]:02X} {sp[:2]}", "7F 31 13", "length", rid)
        add("Unknown routine id", ["ext"], "31 01 FF FF", "7F 31 31", "negative", "REQ-31")
    add("Unknown service rejected", [], "99", "7F 99 11", "negative", "REQ-GEN")
    return out
