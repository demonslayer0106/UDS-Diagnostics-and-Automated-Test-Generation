
import argparse
import sys
from pathlib import Path
from .ecu import PackECU, parse_hex, fmt, NRC
from .suite import run_suite, run_generated
from .generator import load_spec, save_spec, generate
from .assistant import apply_requirement
from .export import to_csv, to_pytest


def _report(results):
    for r in results:
        print("PASS" if r["passed"] else "FAIL", r["case"], "|", r["request"], "->", r["got"])
    ok = sum(r["passed"] for r in results)
    print(f"{ok}/{len(results)} passed")
    return 0 if ok == len(results) else 1


def _generate(spec, args):
    cases = generate(spec)
    print(f"Generated {len(cases)} cases from spec.")
    if args.csv: Path(args.csv).write_text(to_csv(cases)); print("Wrote", args.csv)
    if args.pytest: Path(args.pytest).write_text(to_pytest(cases)); print("Wrote", args.pytest)
    return _report(run_generated(cases)) if args.run else 0


def main(argv=None):
    p = argparse.ArgumentParser(prog="packbench")
    sub = p.add_subparsers(dest="cmd")
    sub.add_parser("suite"); sub.add_parser("repl")
    g = sub.add_parser("generate")
    a = sub.add_parser("ask"); a.add_argument("text"); a.add_argument("--save", action="store_true")
    for sp in (g, a):
        sp.add_argument("--run", action="store_true"); sp.add_argument("--csv"); sp.add_argument("--pytest")
    args = p.parse_args(argv)
    if args.cmd in (None, "suite"):
        return _report(run_suite())
    if args.cmd == "generate":
        return _generate(load_spec(), args)
    if args.cmd == "ask":
        spec, notes = apply_requirement(load_spec(), args.text)
        print("\n".join(notes))
        if args.save: save_spec(spec); print("Spec saved.")
        return _generate(spec, args)
    ecu = PackECU()
    print("Type hex frames (e.g. 10 03). Ctrl-D to quit.")
    for line in sys.stdin:
        try:
            reply = ecu.handle(parse_hex(line))
        except ValueError:
            print("not valid hex"); continue
        note = NRC.get(reply[2], "") if reply and reply[0] == 0x7F else ""
        print(fmt(reply), note, ecu.state())
    return 0


if __name__ == "__main__":
    sys.exit(main())
