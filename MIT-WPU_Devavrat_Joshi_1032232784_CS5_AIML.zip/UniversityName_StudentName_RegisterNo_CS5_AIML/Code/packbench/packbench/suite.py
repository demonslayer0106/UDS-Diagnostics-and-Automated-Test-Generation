
from .ecu import PackECU, key_for, parse_hex, fmt

CASES = [
    ("Enter extended session", [], "10 03", "50 03"),
    ("Reject unknown session", [], "10 07", "7F 10 12"),
    ("Reject short session frame", [], "10", "7F 10 13"),
    ("Read pack voltage", [], "22 0A 01", "62 0A 01 0E 74"),
    ("Reject unknown DID", [], "22 FF FF", "7F 22 31"),
    ("Seed refused in default session", [], "27 01", "7F 27 7F"),
    ("Seed granted in extended session", ["ext"], "27 01", "67 01"),
    ("Key without seed", ["ext"], "27 02 00 00 00 00", "7F 27 24"),
    ("Wrong key", ["ext", "seed"], "27 02 00 00 00 00", "7F 27 35"),
    ("Correct key", ["ext", "seed"], "27 02 KEY", "67 02"),
    ("Write while locked", ["ext"], "2E 0B 01 0E 42", "7F 2E 33"),
    ("Write in range while unlocked", ["ext", "seed", "key"], "2E 0B 01 0E 42", "6E 0B 01"),
    ("Write out of range", ["ext", "seed", "key"], "2E 0B 01 13 88", "7F 2E 31"),
    ("Contactor test, no current", ["ext"], "31 01 03 01", "71 01 03 01"),
    ("Contactor test under load", ["ext", "amps"], "31 01 03 01", "7F 31 22"),
    ("Silent ping", [], "3E 80", "none"),
    ("Reset refused in default session", [], "11 01", "7F 11 7F"),
    ("Reset relocks security", ["ext", "seed", "key"], "11 01", "51 01"),
]


def _step(ecu: PackECU, name: str):
    if name == "ext": ecu.handle(bytes([0x10, 3]))
    elif name == "seed": ecu.handle(bytes([0x27, 1]))
    elif name == "key": ecu.handle(bytes([0x27, 2]) + key_for(ecu.seed).to_bytes(4, "big"))
    elif name == "amps": ecu.amps = 20


def run_case(name, setup, request, expected) -> dict:
    ecu = PackECU()
    for step in setup:
        _step(ecu, step)
    if "KEY" in request:
        request = request.replace("KEY", fmt(key_for(ecu.seed).to_bytes(4, "big")))
    got = fmt(ecu.handle(parse_hex(request)))
    want = "(no reply)" if expected == "none" else expected
    return {"case": name, "request": request, "expected": want, "got": got, "passed": got.startswith(want)}


def run_suite() -> list:
    return [run_case(*c) for c in CASES]


def run_generated(cases) -> list:
    return [run_case(c["name"], c["setup"], c["request"], c["expected"]) | {"req_id": c["req_id"], "category": c["category"]}
            for c in cases]
