# Evaluation Summary (v1.0)

| Measure | Result |
|---|---|
| Generated cases passing against the simulator | 44 of 44 |
| Hand-written baseline suite | 18 of 18 |
| Requirement IDs covered | 14 |
| Automated unit tests | 28 passed, 1 warning in 0.50s |
| Seeded specification errors detected | 4 of 7 |
| Sample requirements mapped by the assistant | 6 of 8 |

## Cases by category
- nominal: 14
- negative: 8
- length: 7
- suppress: 2
- session: 4
- sequence: 1
- security: 3
- boundary: 4
- environment: 1

## Seeded specification errors
- 2E 0B01 max lowered to 4100: detected
- 2E 0B01 min raised to 3100: detected
- 2E 0B01 security requirement removed: detected
- 2E 0B01 session requirement removed: detected
- 11 session requirement removed: NOT detected
- 31 0301 current block removed: NOT detected
- 27 session requirement removed: NOT detected

The undetected cases all remove a requirement from the specification, so the matching negative test is no longer generated. This is a limitation of purely specification-driven generation.

## Files
- RegisterNo_GeneratedMatrix_v1.0.csv: every generated case with requirement ID
- RegisterNo_RunResults_v1.0.csv: result of running each case
- RegisterNo_AssistantResults_v1.0.csv: assistant on the sample requirements
- RegisterNo_PytestLog_v1.0.txt: unit-test output
