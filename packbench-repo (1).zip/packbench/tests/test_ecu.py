import pytest
from fastapi.testclient import TestClient
from packbench import PackECU, key_for
from packbench.api import app
from packbench.suite import run_suite


@pytest.mark.parametrize("r", run_suite(), ids=lambda r: r["case"])
def test_suite_case(r):
    assert r["passed"], f'{r["case"]}: wanted {r["expected"]}, got {r["got"]}'


def test_key_is_deterministic_and_32bit():
    assert key_for(0xA5C30001) == key_for(0xA5C30001) < 2**32


def test_reset_keeps_current():
    e = PackECU(amps=15); e.handle(bytes([0x10, 3])); e.handle(bytes([0x11, 1]))
    assert e.amps == 15 and e.session == 1


def test_seed_is_single_use():
    e = PackECU(); e.handle(bytes([0x10, 3])); e.handle(bytes([0x27, 1]))
    e.handle(bytes([0x27, 2, 0, 0, 0, 0]))
    assert e.handle(bytes([0x27, 2, 0, 0, 0, 0])) == bytes([0x7F, 0x27, 0x24])


def test_api_roundtrip():
    c = TestClient(app)
    assert c.post("/send", json={"hex": "10 03"}).json()["reply"].startswith("50 03")
    assert c.post("/send", json={"hex": "zz"}).status_code == 422
    assert c.get("/suite").json()["passed"] == 18
