from packbench.generator import load_spec, generate
from packbench.suite import run_generated
from packbench.assistant import apply_requirement
from packbench.export import to_csv, to_pytest


def test_generated_cases_pass_against_ecu():
    cases = generate(load_spec())
    assert len(cases) > 40
    assert {"nominal", "boundary", "security", "session", "length", "suppress"} <= {c["category"] for c in cases}
    bad = [r for r in run_generated(cases) if not r["passed"]]
    assert not bad, bad


def test_spec_mismatch_is_caught():
    spec = load_spec()
    spec["services"]["2E"]["dids"]["0B01"]["max"] = 4100  # ECU still accepts up to 4200
    failed = [r["case"] for r in run_generated(generate(spec)) if not r["passed"]]
    assert "Write 0B01 above maximum" in failed


def test_assistant_updates_range():
    spec, notes = apply_requirement(load_spec(), "Writes to DID 0B01 need an unlocked extended session, range 3200 to 4000 mV")
    d = spec["services"]["2E"]["dids"]["0B01"]
    assert (d["min"], d["max"], d["security"]) == (3200, 4000, True) and notes


def test_assistant_reports_unknown_text():
    spec, notes = apply_requirement(load_spec(), "make it faster")
    assert spec == load_spec() and "Could not map" in notes[0]


def test_new_requirement_exposes_missing_ecu_feature():
    spec, _ = apply_requirement(load_spec(), "Writes to DID 0C01 need an extended session, range 10 to 20")
    assert any(not r["passed"] for r in run_generated(generate(spec)))


def test_exports():
    cases = generate(load_spec())
    assert to_csv(cases).splitlines()[0] == "req_id,category,name,setup,request,expected"
    ns = {}
    exec(compile(to_pytest(cases), "gen", "exec"), ns)
    assert len(ns["CASES"]) == len(cases)
