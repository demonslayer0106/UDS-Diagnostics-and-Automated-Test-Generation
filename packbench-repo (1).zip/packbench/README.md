# PackBench

A practice bench for UDS (ISO 14229) requests against a **simulated** battery-pack controller.

> Simulation only. Do not connect this to a real vehicle, ECU or production CAN bus.

## What it does
- `packbench/ecu.py`: session and security state machine, DID reads and writes, a routine gated on pack current, negative response codes, suppress-positive-response bit.
- `packbench/suite.py`: 18 rule cases with setup steps and expected reply prefixes.
- `packbench/api.py`: FastAPI endpoints `/state`, `/send`, `/reset`, `/suite`.
- `packbench/cli.py`: run the suite or type frames in a small REPL.

## Test generation
`packbench/spec.json` describes the ECU's services, DIDs, ranges and preconditions. `generator.py` turns it into test cases (nominal, wrong length, bad subfunction, wrong session, locked security, boundary values, environment, suppressed replies). Expected replies come from the spec, not the ECU code, so a mismatch shows up as a failing case.

```
python -m packbench.cli generate --run --csv matrix.csv --pytest test_generated.py
python -m packbench.cli ask "Writes to DID 0B01 need an unlocked extended session, range 3200 to 4000 mV" --run
```
`ask` is a rule-based assistant: it maps a plain-English requirement to spec changes and regenerates tests. Add `--save` to keep the change. Review generated tests before use. Each case carries a requirement id for traceability in the CSV.

## Run
```
pip install -r requirements.txt
python -m packbench.cli suite
python -m packbench.cli repl
uvicorn packbench.api:app --reload   # docs at /docs
pytest
```

## Simulated ECU reference
Services: 10, 11, 22, 27, 2E, 31, 3E. DIDs: F190 (VIN), 0A01 (voltage), 0A02 (temperature), 0A03 (state of charge), 0B01 (cell balance limit, writable, 3000 to 4200 mV). Routine 0301 (contactor test) needs extended session and 0 A. Security key = seed rotated left 7 bits XOR 0x3C6B91D4.
