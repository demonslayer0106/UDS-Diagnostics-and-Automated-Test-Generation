"""Simulated battery-pack controller. Simulation only: never connect to a real bus."""
import secrets

NRC = {0x11: "serviceNotSupported", 0x12: "subFunctionNotSupported", 0x13: "incorrectLength",
       0x22: "conditionsNotCorrect", 0x24: "requestSequenceError", 0x31: "requestOutOfRange",
       0x33: "securityAccessDenied", 0x35: "invalidKey", 0x7F: "serviceNotSupportedInActiveSession"}
SERVICES = {0x10: "SessionControl", 0x11: "ECUReset", 0x22: "ReadDataByIdentifier",
            0x27: "SecurityAccess", 0x2E: "WriteDataByIdentifier", 0x31: "RoutineControl",
            0x3E: "TesterPresent"}
SESSIONS = {1: "default", 2: "programming", 3: "extended"}
VIN = b"BMSLABPACK000001"
LIMIT_DID, ROUTINE_ID = 0x0B01, 0x0301
LIMIT_MIN_MV, LIMIT_MAX_MV = 3000, 4200


def rotl(x: int, n: int) -> int:
    return ((x << n) | (x >> (32 - n))) & 0xFFFFFFFF


def key_for(seed: int) -> int:
    """Rotate the seed left by 7 bits, then XOR with a fixed mask."""
    return rotl(seed, 7) ^ 0x3C6B91D4


def parse_hex(text: str) -> bytes:
    return bytes(int(t, 16) for t in text.replace(",", " ").split())


def fmt(data) -> str:
    return "(no reply)" if data is None else " ".join(f"{b:02X}" for b in data)


class PackECU:
    def __init__(self, amps: int = 0):
        self.reset(amps)

    def reset(self, amps: int = 0):
        self.session, self.unlocked, self.seed = 1, False, None
        self.amps, self.cell_mv = amps, 3650

    @staticmethod
    def _neg(sid, code):
        return bytes([0x7F, sid, code])

    def _read(self, did):
        table = {0xF190: VIN, 0x0A01: bytes([0x0E, 0x74]), 0x0A02: bytes([65]),
                 0x0A03: bytes([72]), LIMIT_DID: self.cell_mv.to_bytes(2, "big")}
        return table.get(did)

    def state(self) -> dict:
        return {"session": SESSIONS[self.session], "unlocked": self.unlocked,
                "cell_limit_mv": self.cell_mv, "amps": self.amps}

    def handle(self, req: bytes):
        """Return the reply bytes, or None when a positive reply is suppressed."""
        if not req:
            raise ValueError("empty request")
        sid, n = req[0], len(req)
        if sid not in SERVICES:
            return self._neg(sid, 0x11)
        sub = req[1] if n > 1 else 0
        quiet, sf = bool(sub & 0x80), sub & 0x7F
        bad = self._neg
        if sid == 0x10:
            if n != 2: return bad(sid, 0x13)
            if sf not in SESSIONS: return bad(sid, 0x12)
            self.session, self.unlocked, self.seed = sf, False, None
            return None if quiet else bytes([0x50, sf, 0, 0x32, 1, 0xF4])
        if sid == 0x11:
            if n != 2: return bad(sid, 0x13)
            if sf not in (1, 3): return bad(sid, 0x12)
            if self.session == 1: return bad(sid, 0x7F)
            self.reset(self.amps)
            return None if quiet else bytes([0x51, sf])
        if sid == 0x3E:
            if n != 2: return bad(sid, 0x13)
            if sf: return bad(sid, 0x12)
            return None if quiet else bytes([0x7E, 0])
        if sid == 0x22:
            if n < 3 or n % 2 == 0: return bad(sid, 0x13)
            out = bytearray([0x62])
            for i in range(1, n, 2):
                value = self._read(req[i] << 8 | req[i + 1])
                if value is None: return bad(sid, 0x31)
                out += req[i:i + 2] + value
            return bytes(out)
        if sid == 0x27:
            if self.session == 1: return bad(sid, 0x7F)
            if sf == 1:
                if n != 2: return bad(sid, 0x13)
                self.seed = 0xA5C30000 + secrets.randbelow(65535) + 1
                return bytes([0x67, 1]) + self.seed.to_bytes(4, "big")
            if sf == 2:
                if n != 6: return bad(sid, 0x13)
                if self.seed is None: return bad(sid, 0x24)
                given, seed, self.seed = int.from_bytes(req[2:], "big"), self.seed, None
                if given != key_for(seed): return bad(sid, 0x35)
                self.unlocked = True
                return bytes([0x67, 2])
            return bad(sid, 0x12)
        if sid == 0x2E:
            if n != 5: return bad(sid, 0x13)
            if (req[1] << 8 | req[2]) != LIMIT_DID: return bad(sid, 0x31)
            if self.session == 1: return bad(sid, 0x7F)
            if not self.unlocked: return bad(sid, 0x33)
            value = req[3] << 8 | req[4]
            if not LIMIT_MIN_MV <= value <= LIMIT_MAX_MV: return bad(sid, 0x31)
            self.cell_mv = value
            return bytes([0x6E, req[1], req[2]])
        # 0x31 RoutineControl
        if n != 4: return bad(sid, 0x13)
        if sf not in (1, 3): return bad(sid, 0x12)
        if (req[2] << 8 | req[3]) != ROUTINE_ID: return bad(sid, 0x31)
        if self.session == 1: return bad(sid, 0x7F)
        if sf == 1 and self.amps > 0: return bad(sid, 0x22)
        return bytes([0x71, sf, 3, 1, 0])
