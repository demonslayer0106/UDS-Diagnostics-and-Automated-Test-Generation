"""REST wrapper: uvicorn packbench.api:app"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from .ecu import PackECU, parse_hex, fmt
from .suite import run_suite

app = FastAPI(title="PackBench", description="Simulation only. Not for real vehicles.")
ecu = PackECU()


class Frame(BaseModel):
    hex: str


@app.get("/state")
def state(): return ecu.state()


@app.post("/send")
def send(frame: Frame):
    try:
        req = parse_hex(frame.hex)
        reply = ecu.handle(req)
    except ValueError:
        raise HTTPException(422, "Send hex bytes such as '22 0A 01'")
    return {"request": fmt(req), "reply": fmt(reply), "state": ecu.state()}


@app.post("/reset")
def reset():
    ecu.reset()
    return ecu.state()


@app.get("/suite")
def suite():
    results = run_suite()
    return {"passed": sum(r["passed"] for r in results), "total": len(results), "results": results}


from .generator import load_spec, generate  # noqa: E402
from .assistant import apply_requirement  # noqa: E402
from .suite import run_generated  # noqa: E402


class Requirement(BaseModel):
    text: str


@app.get("/generate")
def generate_cases(run: bool = False):
    cases = generate(load_spec())
    return {"count": len(cases), "cases": cases, "results": run_generated(cases) if run else None}


@app.post("/assist")
def assist(req: Requirement):
    spec, notes = apply_requirement(load_spec(), req.text)
    cases = generate(spec)
    return {"notes": notes, "count": len(cases), "results": run_generated(cases)}
